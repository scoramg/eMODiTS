/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SAX.SAX_pp;

/**
 *
 * @author amarquezgr
 */
public class HarmonyMemory {
    private int HMS;
    private Harmony HM[];
    
    
    public void setHMS(int HMS) {
        this.HMS = HMS;
    }

    public void setHM(Harmony[] HM) {
        this.HM = HM;
    }

    public int getHMS() {
        return HMS;
    }

    public Harmony[] getHM() {
        return HM;
    }
    
//    public int getNVAR(){
//        return this.getHM()[0].getNVAR();
//    }

    public HarmonyMemory(int HMS, int NVAR) {
        this.HMS = HMS;
        this.HM = new Harmony[HMS];
    }
    
    public void initiator(int NVAR, double low[], double high[]) {
        for (int i = 0; i < HMS; i++) {
            HM[i] = new Harmony(NVAR);
            HM[i].initialize(NVAR, low, high);
        }
    }
    
    public int getWorst(){
        double worst = getHM()[0].getFitness();
        int worstIndex = 0;
        for (int i = 0; i <  getHMS(); i++)
            if (getHM()[i].getFitness() > worst) {
                worst = getHM()[i].getFitness();
                worstIndex = i;
            }
        return worstIndex;
    }
    
    public int getBest(){
        double best = getHM()[0].getFitness();
        int bestIndex = 0;
        for (int i = 0; i < getHMS(); i++)
            if (getHM()[i].getFitness() < best) {
                best = getHM()[i].getFitness();
                bestIndex = i;
            }
        return bestIndex;
    }
    
    public void replaceAt(int i, Harmony h){
        HM[i] = h.clone();
    }
    
    public void replaceAt(int i, Harmony h, double fitness){
        HM[i] = h.clone();
        HM[i].setFitness(fitness);
    }
}
