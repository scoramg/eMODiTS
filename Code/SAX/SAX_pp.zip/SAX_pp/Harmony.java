/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SAX.SAX_pp;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author amarquezgr
 */
public class Harmony implements Cloneable {
//    int a, w;
    private double h[];
    private double fitness;
    
//    private int NVAR;
   
    public double[] getH() {
        return h;
    }

//    public int getNVAR() {
//        return NVAR;
//    }

    public double getFitness() {
        return fitness;
    }

    public void setFitness(double fitness) {
        this.fitness = fitness;
    }

    public void setH(double[] h) {
        this.h = h.clone();
    }

//    public void setNVAR(int NVAR) {
//        this.NVAR = NVAR;
//    }
//
    public Harmony(int NVAR) {
        h = new double[NVAR];
        this.fitness = Double.POSITIVE_INFINITY;
    }

//    public Harmony() {
//    }

    public void initialize(int NVAR, double low[], double high[]){
        RandomGenerator randGen = new RandomGenerator(1234);
        for (int j = 0; j < NVAR; j++) {
            h[j] = randGen.randVal(low[j], high[j]);
//            System.out.print(HM[i][j] + "  ");
        }
        fitness();
    }
    
    public void fitness() {
        setFitness(h[1] + h[4] + h[2] + h[0] + h[3]);
    }
    
    public void repaceAt(int index, double value){
        h[index] = value;
    }
    
    @Override
    public Harmony clone(){
        try {
            super.clone();
            Harmony clon = new Harmony(h.length);
            clon.setFitness(fitness);
            clon.setH(h);
            return clon;
        } catch (CloneNotSupportedException ex) {
            Logger.getLogger(Harmony.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("h=[");
        for(int i=0; i<h.length;i++){
            sb.append(h[i]).append(" ");
        }
        sb.append("]").append("\n");
        sb.append("fitness: ").append(fitness);
        return sb.toString();
    }
    
    
}
