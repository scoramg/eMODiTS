package SAX.SAX_pp;

public class HarmonySearch {
    private HarmonyMemory HM;
    private int maxIter, NVAR;
    private double PAR;
    private double BW;
    private double HMCR;
    private double low[];
    private double high[];
    private Harmony NCHV;
    private double bestFitHistory[];
    private Harmony bestHarmony;
    private double worstFitHistory[];

    static int generation = 0;
    private boolean terminationCriteria = true;
    
    RandomGenerator randGen = new RandomGenerator(1234);

    public void setMaxIteration(int maxIter) {
            this.maxIter = maxIter;
    }

    
    public void setPAR(double PAR) {
            this.PAR = PAR;
    }

    public void setHMCR(double HMCR) {
            this.HMCR = HMCR;
    }

    public void setBW(double BW) {
            this.BW = BW;
    }

    public HarmonyMemory getHM() {
        return HM;
    }

    public void setHM(HarmonyMemory HM) {
        this.HM = HM;
    }

    public HarmonySearch(int NVAR, int HMS, int maxIter, double PAR, double BW, double HMCR) {
        this.NVAR = NVAR;
        this.maxIter = maxIter;
        this.PAR = PAR;
        this.BW = BW;
        this.HMCR = HMCR;
        low = new double[NVAR];
        high = new double[NVAR];
//        NCHV = new double[NVAR];
        NCHV = new Harmony(NVAR);
        bestHarmony = new Harmony(NVAR);
        bestFitHistory = new double[maxIter + 1];
        worstFitHistory = new double[maxIter + 1];
//            HM = new double[HMS][NVAR + 1];
        HM = new HarmonyMemory(HMS, NVAR);
    }

    public void setBounds(double low[], double high[]) {
            this.low = low;
            this.high = high;
    }


    public boolean stopCondition() {
            if (generation > maxIter)
                    terminationCriteria = false;
            return terminationCriteria;

    }

    public void updateHarmonyMemory(double newFitness) {

            // find worst harmony
            int worstIndex = HM.getWorst();
            Harmony worst = HM.getHM()[worstIndex];
            worstFitHistory[generation] = worst.getFitness();
            // update harmony
            if (newFitness < worst.getFitness()) {
                HM.replaceAt(worstIndex, NCHV, newFitness);
            }

            // find best harmony
            int bestIndex = HM.getBest();
            Harmony best = HM.getHM()[bestIndex];
            bestFitHistory[generation] = best.getFitness();
            if (generation > 0 && best.getFitness() != bestFitHistory[generation - 1]) {
                bestHarmony = best.clone();
            }
    }

    private void memoryConsideration(int varIndex) {
//            RandomGenerator randGen = new RandomGenerator(1234);
//            NCHV.getH()[varIndex] = HM.getHM()[randGen.randVal(0, HM.getHMS() - 1)].getH()[varIndex];
            int i = randGen.randVal(0, HM.getHMS() - 1);
            double value = HM.getHM()[i].getH()[varIndex];
            NCHV.repaceAt(varIndex, value);
            
    }

    private void pitchAdjustment(int varIndex) {
        double rand = randGen.ran1();
        double temp = NCHV.getH()[varIndex];
        if (rand < 0.5) {
            temp += rand * BW;
            if (temp < high[varIndex])
//                    NCHV.getH()[varIndex] = temp;
                NCHV.repaceAt(varIndex, temp);
        } else {
            temp -= rand * BW;
            if (temp > low[varIndex])
//                    NCHV.getH()[varIndex] = temp;
                NCHV.repaceAt(varIndex, temp);
        }

    }

    private void randomSelection(int varIndex) {
//        RandomGenerator randGen = new RandomGenerator(1234);
//        NCHV.getH()[varIndex] = randGen.randVal(low[varIndex], high[varIndex]);
        NCHV.repaceAt(varIndex, randGen.randVal(low[varIndex], high[varIndex]));
    }

    public void mainLoop() {
//        RandomGenerator randGen = new RandomGenerator(1234);
        long startTime = System.currentTimeMillis();
        HM.initiator(this.NVAR,this.low, this.high);

        while (stopCondition()) {

                for (int i = 0; i < this.NVAR; i++) {
                        if (randGen.ran1() < HMCR) {
                                memoryConsideration(i);
                                if (randGen.ran1() < PAR)
                                        pitchAdjustment(i);
                        } else
                                randomSelection(i);
                }
                NCHV.fitness();
//                    double currentFit;
//                    currentFit = fitness(NCHV);
//                    updateHarmonyMemory(currentFit);
                updateHarmonyMemory(NCHV.getFitness());
                generation++;

        }
        long endTime = System.currentTimeMillis();
        System.out.println("Execution time : " + (endTime - startTime) / 1000.0
                        + " seconds");
        System.out.println("best :" + bestHarmony.toString());
    }

}
